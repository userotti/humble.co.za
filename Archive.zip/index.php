<!DOCTYPE html>
<html>
  <head>
    <title>humble</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <link href="css/bootstrap_yeti.css" rel="stylesheet" media="screen">
    <link href="css/style.css" rel="stylesheet" media="screen">
    
    <link rel="icon" 
      type="image/ico" 
      href="img/favicon.ico">
  </head>
  
  <body>

   <!-- MAIN CONTAINER -->

   <div class="container" id="main_container">
   
    
    <?php  include 'nav.php' ?>

  
    <div class="jumbotron_index">
      <div class="col-sl-offset-1">
        <p id="jumbo_humble_txt">humble</p>
        <p id="jumbo_oneline_txt">We Love Retail</p>
        <p id="jumbo_index_paragraph"> </p>
        <a type="button" class="btn btn-success" id="jumbo-button" href="register.php">Click here for a free trial</a>
      </div>
    </div> 


    <div style="background-color: #f4f4f4; margin-top: 35px; ">
      <div  class="bodytag_shape" style="background-image: url('img/features_tag.svg');">
   
       
      </div>  
    </div>

    <div class="row" style="margin: 0px; ">
    <div  style="margin-top: 35px; align: center; paddin-left: auto;">


        <div class="col-md-4 features_columns_index"> <h2> Cloud Services </h2> <p>The humble till is a cloud based POS System, which functions with or without an internet connection. This means no unnecessary cables. Stored and backed up automatically within “your cloud” there is no need to worry about managing your stores data security or any unnecessary hardware again. Your store will always be with you.</p>
         
        
          <div id="f1_container">
          <div id="f1_card" class="shadow">
            <div class="front face">
               <img class="features_img_index" src="img/cloud_icon.svg">
            </div>
            <div class="back face center">
               <img class="features_img_index" src="img/humble_logo_circle.svg">
            </div>
          </div>
          </div>

        </div>

        <div class="col-md-4 features_columns_index" style="border-left: 1px solid #dddddd; border-right: 1px solid #dddddd"> <h2> Mobile Friendly </h2> <p>Designed to work using only a web browser. The humble till can be used on a mobile device, allowing you to take your business anywhere.
Try our downloadable humble till iOS Application available on the App Store.</p> 
          <div id="f1_container">
          <div id="f1_card" class="shadow">
            <div class="front face">
               <img class="features_img_index" src="img/mobile_icon.svg">
            </div>
            <div class="back face center">
               <img class="features_img_index" src="img/humble_logo_circle.svg">
            </div>
          </div>
          </div>
        </div>

        <div class="col-md-4 features_columns_index" >  <h2> Super Simple </h2> <p>Designed by retail for retail.
The humble till has been designed with the simple ethos of simplicity, in mind. Intuitive and easy to use, no need to worry about learning all over again. Allowing you to utilise your time more effectively. </p> 
         <div id="f1_container">
          <div id="f1_card" class="shadow">
            <div class="front face">
               <img class="features_img_index" src="img/easy_icon.svg">
            </div>
            <div class="back face center">
               <img class="features_img_index" src="img/humble_logo_circle.svg">
            </div>
          </div>
          </div>
        </div>


    </div>
    </div>

     <div style="background-color: #f4f4f4; margin-top: 95px;  ">
      <div  class="bodytag_shape" style="background-image: url('img/getting_tag.svg'); background-position: right top;">
   
        
      </div>  
    </div>




    <div class="row" style="margin: 0px">
    <div  style="margin-top: 15px; align: center; paddin-left: auto;">

        
        <div class="col-md-4 features_columns_index" style="border-left: 1px solid #dddddd; ">  
          <h2> What you <strong> need </strong>: </h2>
          <br>
           <p>Getting started with the humble till is easy. Simply register on our website and choose a package that is right for your business.
Use the <a href="https://itunes.apple.com/za/app/humble-till/id796942465?mt=8">downloadable application</a> or simply sign in to use your <a href="signin"> web based </a> humble till.
           
          </p>

          <p>The app currently supports the following devices: </p>
           <ul>
            <li>iPhone: 4 / 4S / 5 / 5S</li>
            <li>iPad: 2 / 3 / 4 / Air</li>
          
           </ul> 



        </div>

        <div class="col-md-4 features_columns_index" style="border-left: 1px solid #dddddd; ">  
          <h2> What you <strong>want</strong>: </h2>
          <br>
           <p>The humble till has great hardware associated with it. The kova Stand, makes using and securing your till so much simpler. The Socket Mobile Barcode Scanners speak directly with your till, making inventory management a breeze - great, during a stock take.



          </p>

          <p>humble till friendly hardware: </p>
           <ul>
            <li> Socket Mobile Scanners </li>
            <li> Kova Till Stand </li>
            <li> Epson Slip Printer </li>
            
           </ul> 


        </div>


        <div class="col-md-4 features_columns_index"> 
          <img class="process_img_index" src="img/productscircle.png">
        </div>
      

    </div>
    </div>



    


    <div style="background-color: #f4f4f4; margin-top: 35px; ">
      <div  class="bodytag_shape" style="background-image: url('img/pricing_tag.svg');">
   
       
      </div>  
    </div>

    <div class="row" style="margin: 0px;" >
    <div  style="margin-top: 35px; align: center; paddin-left: auto;">

        <div class="col-md-3 pricing_columns_index" > <h2> Basic  </h2> <p>This package is intended to allow users to experience the till and explore its features and benefits. </p>
          <ul>

            <li> 1 till </li>
            <li> 10 Products </li>
            <li> 1 users </li>
            
           </ul> 
         <a type="button" class="btn btn-success" id="pricing-button" href="register.php">Free</a>



        </div>

        <div class="col-md-3 pricing_columns_index"> <h2> Bronze  </h2> <p>The Bronze package is intended for a business looking to simplify their sales process. From classic retail to restaurants, this is the package for you.</p> 
           <ul>
            <li> Up to 2 tills </li>
            <li> 50 Products </li>
            <li> Up to 5 users </li>
            
           </ul> 
           <a type="button" class="btn btn-success" id="pricing-button" href="register.php">R195 per month</a>
        </div>

        <div class="col-md-3 pricing_columns_index" style="background-color: #98dfb3; color: #ffffff">  <h2> Gold  </h2> <p>The Gold package is aimed at businesses who are looking at expanding. It allows the owner to have one central database which keeps track of all your individual outlets.</p> 
           <ul>
            <li> Up to 5 tills  </li>
            <li> 100 Products </li>
            <li> Up to 10 users </li>
            
           </ul> 
          <a type="button" class="btn btn-success" id="pricing-button" href="register.php"> R245 per till</a>

        </div>

         <div class="col-md-3 pricing_columns_index">  <h2> Premium  </h2> <p> Large franchises need to have one central datastore that connects all of the stores' sales information. This package does exactly that. It allows you to make choices about the future of you business depending on the data stored in the cloud.</p> 
           <ul>
            <li> Unlimited tills </li>
            <li> Unlimited products </li>
            <li> Unlimited users </li>
            
           </ul> 

           <a type="button" class="btn btn-success" id="pricing-button" href="register.php"> R495 per till</a>
        </div>


    </div>
    </div>

<!--
    <div style="background-color: #f4f4f4; margin-top: 95px;  ">
      <div  class="bodytag_shape" style="background-image: url('img/process_tag.svg'); background-position: right top;">
   
        
      </div>  
    </div>

      
   <div class="row" style="margin: 0px">
    <div  style="margin-top: 15px; align: center; paddin-left: auto;">

        <div class="col-md-5 features_columns_index"> 
          <img class="process_img_index" src="img/tillcakecircle.png">
        </div>

        <div class="col-md-6 features_columns_index" style="border-left: 1px solid #dddddd; ">  
          <h2> The humble process </h2>
           <p>Make your way </p>
        </div>

      

    </div>
    </div>
-->

     <div style="background-color: #f4f4f4; margin-top: 95px;  ">
      <div  class="bodytag_shape" style="background-image: url('img/questions2_tag.svg'); background-position: right top;">
   
        
      </div>  
    </div>


    <div class="row" style="margin: 0px">
    <div  style="margin-top: 15px; align: center; paddin-left: auto;">

        <div class="col-md-6 features_columns_index"> 

          <p class="question_text"> <strong>  Who can use the humble till? </strong> </p>
           <p>The humble till can be used by single store operators or small to medium retail chains.</p>

           <br>
        
          <p class="question_text"> <strong>  
How quickly can i integrate the humble till into my business ?</strong> </p>
           <p>Integration of the humble till is as simple as registering on our website and choosing the package that suits your business.</p>

           <br>
        
          <p class="question_text"> <strong> 
How do i know which humble till package is right for my business ?</strong> </p>
           <p>
Simply send us an email on  <a href="mailto:info@humble.co.za"> info@humble.co.za </a> with a few business specific details and we will call you back to discuss and choose the right humble till package for your business.</p>
        
        </div>

        <div class="col-md-6 features_columns_index">  
          

          <p class="question_text"> <strong> Support for my humble till ?</strong> </p>
           <p> The humble till has been designed to be easy to use, should something go wrong, we have a dedicated support team ready to help you.
Email them on <a href="mailto:support@humble.co.za"> support@humble.co.za </a> </p>
             <br>

      <!--    <p class="question_text"> <strong>  Who are the humble till </strong> </p>
           <p> If you have a small retail business, then you are ready to start using the till</p>

        
        
           <br>
        
          <p class="question_text"> <strong>  How does the humble customer support system work? </strong> </p>
           <p> If you have a small retail business, then you are ready to start using the till</p>-->
        </div>

      

    </div>
    </div>
 




   <?php include 'footer.php' ?> 


   </div>

   <?php include 'scripts.php' ?>

   
  
  
  </body>
</html>