var products = [{
  
    "name": "humbletill",
    
    "oneline" : "The humble Till",
    "jumbo_img_class" : "jumbo_humbletill_img",

  
    "features" : [{  "feature_heading" : "humble Till",
                      "feature_tagline" : "The Humble Till Tag Lne Text",
                      "feature_textbody": "Lorem Ipsum is simply dummy teamxt of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
                      "feat_img_url" : "img/humble_small.jpg",

                 },

                 { "feature_heading" : "Redworld",
                    "feature_tagline" : "Redworld Tag Lne Text",
                    "feature_textbody": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
                    "feat_img_url" : "img/redworld_small.png",

                 },

                 ], 


    "whatyouneed_heading" : "humble Till",
    "whatyouneed_tagline" : "What you need to get your till working",
    
    "whatyouneed_items" : [{'item' : 'ipad', 'amount' : 1},
                           {'item' : 'wifi', 'amount' : 1},
                           {'item' : 'wifi22', 'amount' : 1},
                           {'item' : 'wifi3', 'amount' : 1},
                           {'item' : 'stuff', 'amount' : 1}],

    "what_img_url" : "img/humble_small.jpg",

    "heading_row" : [

                     {'item': 'Features', 'col_class' : 'feat_head_col_class'}, 
                     {'item': 'Free', 'col_class' : 'highlight_package_col_class'},
                     {'item': 'Small', 'col_class' : 'package_col_class'}

                    ], 
                                             

    "table" : [{'row' : [ 
                        
                          {'item': '1 Shop', 'col_class' : 'features_col_class', 'feat_elem': true}, 
                          {'item': true, 'col_class' : 'highlight_package_col_class', 'feat_elem': false}, 
                          {'item': true, 'col_class' : 'package_col_class', 'feat_elem': false}

                        ]},

               {'row' : [

                          {'item': '5 Users', 'col_class' : 'features_col_class', 'feat_elem': true},
                          {'item': false, 'col_class' : 'highlight_package_col_class', 'feat_elem': false},
                          {'item': false, 'col_class' : 'package_col_class', 'feat_elem': false}

                        ]},

               {'row' : [ 

                          {'item': '10 Shops', 'col_class' : 'features_col_class', 'feat_elem': true},
                          {'item': false, 'col_class' : 'highlight_package_col_class', 'feat_elem': false},
                          {'item': false, 'col_class' : 'package_col_class', 'feat_elem': false},

                        ]},

               {'row' : [

                          {'item': 'Online Till', 'col_class' : 'features_col_class', 'feat_elem': true},
                          {'item': false, 'col_class' : 'highlight_package_col_class', 'feat_elem': false},
                          {'item': false, 'col_class' : 'package_col_class', 'feat_elem': false},



                        ]},

               

               ],            



},{

    "name": "redworld",
    
    
    "oneline" : "Redworld Analytics",
    "jumbo_img_class" : "jumbo_redworld_img",
    
    "features" : [{ "feature_heading" : "Redworld",
                    "feature_tagline" : "Redworld Tag Lne Text",
                    "feature_textbody": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
                    "feat_img_url" : "img/redworld_small.png",

                 },

                 { 
                  "feature_heading" : "humble Till",
                      "feature_tagline" : "The Humble Till Tag Lne Text",
                      "feature_textbody": "Lorem Ipsum is simply dummy teamxt of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
                      "feat_img_url" : "img/humble_small.jpg",

                 },

                 ],   

    "whatyouneed_heading" : "Redworld",
    "whatyouneed_tagline" : "What you need to access redworld Analytics",
    "whatyouneed_textbody": "Lorem Ipsum is simply dummy teamxt of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
    "what_img_url" : "img/redworld_small.png",


    "whatyouneed_items" : [{'item' : 'ipad', 'amount' : 1},
                           {'item' : 'wifi', 'amount' : 1},
                           {'item' : 'wifi2', 'amount' : 1},
                           {'item' : 'wifi3', 'amount' : 1},
                           {'item' : 'stuff', 'amount' : 1}],

      "heading_row" : [

                     {'item': 'Features', 'col_class' : 'feat_red_head_col_class'}, 
                     {'item': 'Free', 'col_class' : 'highlight_red_package_col_class'},
                     {'item': 'Small', 'col_class' : 'package_col_class'},
                     {'item': 'Large', 'col_class' : 'package_col_class'},
                     {'item': 'Super', 'col_class' : 'package_col_class'},
                     {'item': 'Great', 'col_class' : 'package_col_class'},


                    ], 
                                             

      "table" : [{'row' : [ 
                        
                          {'item': '1 Shop', 'col_class' : 'feat_red_head_col_class', 'feat_elem': true}, 
                          {'item': true, 'col_class' : 'highlight_red_package_col_class', 'feat_elem': false}, 
                          {'item': true, 'col_class' : 'package_col_class', 'feat_elem': false},
                          {'item': true, 'col_class' : 'package_col_class', 'feat_elem': false},
                          {'item': true, 'col_class' : 'package_col_class', 'feat_elem': false},
                          {'item': true, 'col_class' : 'package_col_class', 'feat_elem': false},

                        ]},

               {'row' : [

                          {'item': '5 Users', 'col_class' : 'feat_red_head_col_class', 'feat_elem': true},
                          {'item': false, 'col_class' : 'highlight_red_package_col_class', 'feat_elem': false},
                          {'item': false, 'col_class' : 'package_col_class', 'feat_elem': false},
                          {'item': true, 'col_class' : 'package_col_class', 'feat_elem': false},
                          {'item': true, 'col_class' : 'package_col_class', 'feat_elem': false},
                          {'item': true, 'col_class' : 'package_col_class', 'feat_elem': false},

                        ]},

               {'row' : [ 

                          {'item': '10 Shops', 'col_class' : 'feat_red_head_col_class', 'feat_elem': true},
                          {'item': false, 'col_class' : 'highlight_red_package_col_class', 'feat_elem': false},
                          {'item': false, 'col_class' : 'package_col_class', 'feat_elem': false},
                          {'item': true, 'col_class' : 'package_col_class', 'feat_elem': false},
                          {'item': true, 'col_class' : 'package_col_class', 'feat_elem': false},
                          {'item': true, 'col_class' : 'package_col_class', 'feat_elem': false},

                        ]},

               {'row' : [

                          {'item': 'Online Till', 'col_class' : 'feat_red_head_col_class', 'feat_elem': true},
                          {'item': false, 'col_class' : 'highlight_red_package_col_class', 'feat_elem': false},
                          {'item': false, 'col_class' : 'package_col_class', 'feat_elem': false},
                          {'item': true, 'col_class' : 'package_col_class', 'feat_elem': false},
                          {'item': true, 'col_class' : 'package_col_class', 'feat_elem': false},
                          {'item': true, 'col_class' : 'package_col_class', 'feat_elem': false},



                        ]},

               

               ],            





}, {

    "name": "pastel",
    
    "oneline" : "My Business Online",
    "jumbo_img_class" : "jumbo_pastel_img",
    "feature_heading" : "Sage Pastel",
    "feature_tagline" : "The pastel Till Tag Lne Text",
    "feature_textbody": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
    "feat_img_url" : "img/pastel_small.jpg",


   
    

}];