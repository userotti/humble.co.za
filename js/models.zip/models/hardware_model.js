


var hardware = [{

  
    "name": "kova",
    "jumbo_img_class": "jumbo_kova_img",
    
    "oneline" : "Kova Till Stand",
    

    
    "features" : [{
                    "feature_heading" : "Kova Stands",
                    "feature_tagline" : "Kova Stand tag line words ",
                    "feature_textbody": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
                    "feat_img_url" : "img/kova_small.jpg",
                  },
                  
                  {
                    "feature_heading" : "Socket",
                    "feature_tagline" : "Socket Moblile tagline words ",
                    "feature_textbody": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
                    "feat_img_url" : "img/socket_small.jpg",
                  },
                  
  
                  ],      

  },


  {
    "name": "socketmobile",
    "jumbo_img_class": "jumbo_socket_img",
 
    "oneline" : "Socket Mobile Scanner",
    

    "features" : [{
                    "feature_heading" : "Socket",
                    "feature_tagline" : "Socket Moblile tagline words ",
                    "feature_textbody": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
                    "feat_img_url" : "img/socket_small.jpg",
                  },
                  
                  {
                    "feature_heading" : "Socket",
                    "feature_tagline" : "Socket Moblile tagline words ",
                    "feature_textbody": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
                    "feat_img_url" : "img/socket_small.jpg",
                  },
                  
  
                  ],      


  },

  {
    "name": "beacons",
    "jumbo_img_class": "jumbo_beacon_img",

    "oneline" : "Bluetooth Beacons",
    

     "features" : [{
                    "feature_heading" : "Beacons",
                    "feature_tagline" : "Beacons tagline words",
                    "feature_textbody": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
                    "feat_img_url" : "http://placehold.it/240x240",
                  },
                  
                  {
                    "feature_heading" : "Socket",
                    "feature_tagline" : "Socket Moblile tagline words ",
                    "feature_textbody": "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
                    "feat_img_url" : "img/socket_small.jpg",
                  },
                  
  
                  ], 
  


}];
