
var contact = {

  "tell" : "033 056 34324",
  "email" : "office@humble.com",



};

var about = {	'heading': 'About humble software',
                'paragraph1': 'At humble software Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feu littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.',
                
                'staff': [{
                	
                	'name' : "William",
                	'left_pos' : true, 
                	'img_url' : 'img/will.png',	
                    'textpara': 'William is a software developer with over 15 years experience in the retail software environment. During this time, he has been severely disruptive in his industry, causing other software companies to play catch-up. Known for his unapologetic dislike of clutter and complexity, he is obsessively focused on making products as simple and useful as it can be. In 2013, he founded a software company called humble, with the aim of making retail software that people actually like.',
	                
	                },

	                {	
	                 
	                'name' : "Rodney",
                	'left_pos' : false, 
                	'img_url' : 'img/rod.png',	
	                'textpara' : 'Rodney has been involved in the South African mobile telecommunications industry for the last 14 years. He started his career as an engineer with Vodacom and in 2003 left Vodacom and started his own company focusing on retail also with Vodacom. In 2006 he started the development process for a cloud based CRM solution and so began his love for software development and trying to find ways of using software to enhance the customer experience in his business.',

	            	},

	            	{	
	                 
	                'name' : "David",
                	'left_pos' : true, 
                	'img_url' : 'img/rod.png',	
	                'textpara' : 'David has been involved in the South African mobile telecommunications industry for the last 14 years. He started his career as an engineer with Vodacom and in 2003 left Vodacom and started his own company focusing on retail also with Vodacom. In 2006 he started the development process for a cloud based CRM solution and so began his love for software development and trying to find ways of using software to enhance the customer experience in his business.',

	            	},	

                ]
                
         };
